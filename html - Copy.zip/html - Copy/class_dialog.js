var class_dialog =
[
    [ "Dialog", "class_dialog.html#ab30ac48588a82983f653f58d50a52ddc", null ],
    [ "~Dialog", "class_dialog.html#a2a1fe6ef28513eed13bfcd3a4da83ccb", null ]
];