var hierarchy =
[
    [ "Course", "class_course.html", null ],
    [ "Person", "class_person.html", [
      [ "Professor", "class_professor.html", null ],
      [ "Student", "class_student.html", null ]
    ] ],
    [ "QDialog", null, [
      [ "Dialog", "class_dialog.html", null ]
    ] ]
];