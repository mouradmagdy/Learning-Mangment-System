var class_person =
[
    [ "Person", "class_person.html#a9bee5372486fc2efe320e3c484230c37", null ],
    [ "getAge", "class_person.html#a4b66dbee570398920b8fb6aacddd2559", null ],
    [ "getEmail", "class_person.html#adaad27adf5174a8ecc203087487e7aae", null ],
    [ "getFirstName", "class_person.html#ad2c87af66f95169eb3f2be2e4b1bbb86", null ],
    [ "getLastName", "class_person.html#a1e35787153de7b3f910b700df077270e", null ],
    [ "getMobile", "class_person.html#a642d2c23602de7fc9a005afae52a696f", null ],
    [ "setAge", "class_person.html#ad64736ef1db262fefc111b52051bc72b", null ],
    [ "setEmail", "class_person.html#ab49382853cc3f80c39d4b4095f03600c", null ],
    [ "setFirstName", "class_person.html#a0a8a0c8f27ea1f69c6e82fefd26b2187", null ],
    [ "setLastName", "class_person.html#a49aa26183ed46354acfc98c7b678dca8", null ],
    [ "setMobile", "class_person.html#abef40c58fd0aa48a1de21f4c7ad9ac31", null ]
];