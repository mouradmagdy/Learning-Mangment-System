var class_professor =
[
    [ "Professor", "class_professor.html#ada3a4655a4f0f712c3c168827bde6015", null ],
    [ "addCourse", "class_professor.html#abb3dc70e1c3e103ef884513fd8f7b6ca", null ],
    [ "DisplayInfo", "class_professor.html#addd70dab8dd24df978971bc004c4bf7a", null ],
    [ "getCourses", "class_professor.html#a69e1bb4d05ffb5821538723e9cda9485", null ],
    [ "getTitle", "class_professor.html#a7a4a14866772ebbb19c9396d35d09d10", null ],
    [ "operator==", "class_professor.html#ab50e5eefba3e108fabdc11f37d7ba802", null ],
    [ "setTitle", "class_professor.html#a7057f69c6011e1028213c4db6458162c", null ]
];