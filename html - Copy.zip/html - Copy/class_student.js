var class_student =
[
    [ "Student", "class_student.html#a2ef1ea7c67ca34d3b744372fcdb9e5d6", null ],
    [ "addCourse", "class_student.html#ad04161b74511e786f940ad52ee1d9df0", null ],
    [ "getGrade", "class_student.html#aafbe480b26574a9c96c4c912e4369324", null ],
    [ "getGradesForCertainCourse", "class_student.html#aa0be02e80c15a887d9601fb704d8b39c", null ],
    [ "getId", "class_student.html#a10a87a766d0de17564c9a958fa10b7d8", null ],
    [ "getMarksForEveryCourse", "class_student.html#a3a3c58ce40397316885e9e1f51d33b62", null ],
    [ "operator==", "class_student.html#a13d7411e74f21bb62aabfccb6c7e408f", null ],
    [ "setGrade", "class_student.html#acd29732603fdab119f1b26f638d397c3", null ],
    [ "setMark", "class_student.html#aee12bb1da8a146cd7dc1e3cd2b6ba7ee", null ]
];