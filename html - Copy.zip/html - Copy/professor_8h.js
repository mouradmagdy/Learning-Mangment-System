var professor_8h =
[
    [ "Professor", "class_professor.html", "class_professor" ]
];