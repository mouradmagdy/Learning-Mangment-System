var dir_97dfd6d649856a3e8988067998920657 =
[
    [ "course.cpp", "course_8cpp.html", null ],
    [ "course.h", "course_8h.html", "course_8h" ],
    [ "dialog.cpp", "dialog_8cpp.html", "dialog_8cpp" ],
    [ "dialog.h", "dialog_8h.html", "dialog_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "person.cpp", "person_8cpp.html", null ],
    [ "person.h", "person_8h.html", "person_8h" ],
    [ "professor.cpp", "professor_8cpp.html", null ],
    [ "professor.h", "professor_8h.html", "professor_8h" ],
    [ "student.cpp", "student_8cpp.html", null ],
    [ "student.h", "student_8h.html", "student_8h" ]
];