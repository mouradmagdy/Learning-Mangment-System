var annotated_dup =
[
    [ "Course", "class_course.html", "class_course" ],
    [ "Dialog", "class_dialog.html", "class_dialog" ],
    [ "Person", "class_person.html", "class_person" ],
    [ "Professor", "class_professor.html", "class_professor" ],
    [ "Student", "class_student.html", "class_student" ]
];