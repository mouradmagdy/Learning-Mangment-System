var dir_d3ef5c805e729b22770249f991ebeeb6 =
[
    [ "learning_managment_system", "dir_97dfd6d649856a3e8988067998920657.html", "dir_97dfd6d649856a3e8988067998920657" ]
];