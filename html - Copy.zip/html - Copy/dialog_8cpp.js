var dialog_8cpp =
[
    [ "id", "dialog_8cpp.html#a7441ef0865bcb3db9b8064dd7375c1ea", null ],
    [ "index", "dialog_8cpp.html#a750b5d744c39a06bfb13e6eb010e35d0", null ]
];