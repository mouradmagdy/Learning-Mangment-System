var class_course =
[
    [ "Course", "class_course.html#a1d01a572ab8d5ba100a313a69e896514", null ],
    [ "addProfessor", "class_course.html#a34e6234f993de0dd0c23ab49510a141b", null ],
    [ "addStudent", "class_course.html#a9fa419bb7d86b238e29f172a1901e7df", null ],
    [ "getCode", "class_course.html#af7db2a7a1a2efeae239929dca4ed4d02", null ],
    [ "getEnrolledStudentsInCourses", "class_course.html#aa3c85358b3af32322718ba3e3d40fb0d", null ],
    [ "getLectureDay", "class_course.html#a39905c6c1da1aaf984cf534d71f59947", null ],
    [ "getLectureHall", "class_course.html#a262a558a8c4ea5ada530fae28c70d045", null ],
    [ "getLectureTime", "class_course.html#a4d783b9b6201e09df093d26d21904ea6", null ],
    [ "getName", "class_course.html#aa2590d290eafdb4145d2326e0cc1fc48", null ],
    [ "getProfessors", "class_course.html#aa9041cf640a27937282ae1c4f03c9531", null ],
    [ "getTime", "class_course.html#ada01c2ebfae8837037d362b628146ba3", null ],
    [ "operator==", "class_course.html#aea7c2ec7f634b74963a46795f9a8168b", null ],
    [ "setCode", "class_course.html#ab356057c6eb3126b42f1376580b67ff6", null ],
    [ "setLectureHall", "class_course.html#af88f06171446db697f7c404166ffd73b", null ],
    [ "setName", "class_course.html#a92d0cf2686865fff8c579e745709b2fa", null ],
    [ "setTime", "class_course.html#acea8153eff703f359c88b451efa97eb2", null ]
];